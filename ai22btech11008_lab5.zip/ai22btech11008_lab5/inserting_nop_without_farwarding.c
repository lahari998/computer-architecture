#include <stdio.h>
#include <string.h>

int values(char rs[4]){
     char values[10]={"0123456789"};
     for(int i=0;i<10;i++){
         rs[2]!=values[i];
           return 1;}
                }
                
int main(){
FILE *fptr = fopen("input.txt", "r");
if(fptr==NULL){
perror("file not found");
}
char line[100];
int count=0;
char prev[100]="";
while(fgets(line,sizeof(line),fptr)){
     char instruction[4], rd[4], rs1[4], rs2[4];
     
     int assembly_code = sscanf(line, "%s %s %s %s", instruction, rd, rs1, rs2);
     
     if (assembly_code == 4) {
                if (strcmp(prev, rs1) == 0 ) {
                    printf("nop\nnop\n");
                    count=count+2; 
                }
               else if(prev[1]==rs2[1]){
                    if(prev[2]==','){
                      if(values(rs2)){
                      printf("nop\nnop\n");
                count=count+2;}
             else if(prev[2]==rs2[2]){
                printf("nop\nnop\n");
                  count=count+2;}
             }}
            printf("%s %s %s %s\n", instruction, rd, rs1, rs2);
            count++;
        } 
        
       else if (assembly_code == 3) {
            for (int i = 0; i < 6; i++) {
                if (rs1[i] == '(') {
                    if (prev[1] == rs1[i + 2]) {
                        if (prev[2] == ',' && rs1[i + 3] == ')') {
                            printf("nop\nnop\n");
                            count = count + 2;
                        }
                     else if (prev[2] == rs2[i + 3]) {
                        printf("nop\nnop\n");
                        count = count + 2;
                    }}
                }
            }
            printf("%s %s %s\n", instruction, rd, rs1);
            count++;
        }
        
   strcpy(prev, rd);    
}
printf("no of total cycles: %d \n", count+4);
    fclose(fptr);
    return 0;
}
